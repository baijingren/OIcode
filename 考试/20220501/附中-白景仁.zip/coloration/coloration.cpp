#include<bits/stdc++.h>
using namespace std;
#define PII pair<int,int>
#define MP make_pair
const int qwe=1e6+5;
int n,m;
vector<PII> e[qwe];
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=m;i++){
        int a,b,c;
        scanf("%d%d%d",&a,&b,&c);
        e[a].push_back(MP(b,c));
        e[b].push_back(MP(a,c));
    }
    
}