#include<bits/stdc++.h>
using namespace std;
const int qwe=1e6+5;
int T;
int a,b,c;
int ans;
int gcd(int x,int y){
    return y==0?x:gcd(y,x%y);
}
void lcm(int x,int y,int &l,int &r){
    int k=gcd(x,y);
    l=x/k;
    r=y/k;
}
void calc(int x,int y){
    ans=0;
    int l,r;
    lcm(a,b,l,r);
    // cout<<l<<' '<<r<<'a'<<endl;
    ans=y/l;
    // cout<<y/l<<'b'<<endl;
}
void cal(int x, int y,bool d){
    // int k=gcd();
}
int main(){
    freopen("fuction.in","r",stdin);
    freopen("fuction.out","w",stdout);
    scanf("%d",&T);
    while(T--){
        scanf("%d%d%d",&a,&b,&c);
        if(a==0 || b==0){
            printf("1\n");
        }
        if(a<0 && b<0 && c>0){
            printf("0\n");
            continue;
        }
        else if(a>0 && b>0 && c<0){
            printf("0\n");
            continue;
        }
        if(a<0 && b<0 && c<0){
            a=-a;
            b=-b;
            c=-c;
        }
        if(a>0 && b>0){
            for(int i=1;i<=c/a;i++){
                if((c-i*a)%b==0){
                    calc(i,(c-i*a)/b);
                    break;
                }
            }
            if(ans>65535){
                printf("ZenMeZheMeDuo\n");
            }
            else{
                printf("%d\n",ans);
            }
        }
        else{
            printf("ZenMeZheMeDuo\n");
        }
    }
}